../demo_linux satlib_bmc_bcp.cnf satlib_bmc_bcp.log 259 129 0
