uint64  t_total__  = 0;
uint64  t_mark__   = 0;
int     t_reclev__ = 0;
