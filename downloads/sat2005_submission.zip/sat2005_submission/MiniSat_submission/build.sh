make clean
make rs
echo 'DONE! Use "minisat_static" for the contest.'
